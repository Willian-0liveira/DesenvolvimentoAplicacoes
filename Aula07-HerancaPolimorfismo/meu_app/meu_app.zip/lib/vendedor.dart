import 'funcionario.dart';

class Vendedor extends Funcionario{

  double _metaVendas = 0;

  Vendedor(String nome, double salario, double metaVendas) : super(nome, salario){
    this.metaVendas = metaVendas;
  }

  //Getters
  double get metaVendas{
    return _metaVendas; 
  }

  //Setters
  set metaVendas(double novaMetaVendas){
    if (novaMetaVendas < 0){
      throw ArgumentError("Meta não pode ser menor que zero");
    }

    _metaVendas = novaMetaVendas;
  }
}