import 'funcionario.dart';

class Gerente extends Funcionario{

  String _setor = "";

  Gerente(String nome, double salario, String setor) : super(nome, salario){
    this.setor = setor;
  }

  String get setor {
    return _setor;
  }

  set setor(String novoSetor){
    if(novoSetor.trim().isEmpty){
      throw ArgumentError("Nome do setor não pode estar vazio");
    }
    _setor = novoSetor;
  }


} 